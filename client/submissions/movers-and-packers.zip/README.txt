compiler version should be 4.5
boost has to be installed

a Makefile exists in the code directory, so the program can be started with
make run-opt BOARD=1 PORT=7781
