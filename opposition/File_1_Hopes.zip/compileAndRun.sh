#!/bin/sh
jar -xf code.jar
javac *java
rm *java

