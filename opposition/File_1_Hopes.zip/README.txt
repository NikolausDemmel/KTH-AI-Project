After running the bash-file you can run the code using the format:
java Client host port board#
If you for some reason doesn't desire to run it using the command-line interface you 
can change this in the code. At the top of Client.java there's a variable called "CLMode", set this to false and
it'll accept input written straight into the code at lines 31 and 39. (host, port and board number)